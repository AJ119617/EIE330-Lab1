#!/bin/bash
set -uo pipefail
cd "$(dirname "$0")/.."
exec > >(tee Logs/verification.log) 2>&1
run() { echo "COMMAND: $*"; "$@"; r=$?; echo "EXIT_STATUS=$r"; [ "$r" -eq 0 ] || exit "$r"; }
cd RTL
run iverilog -Wall -t null -s comparator comparator.v
cd ../sim
run iverilog -Wall -o comparator_tb.vvp -s comparator_tb -y ../RTL comparator_tb.v
run vvp comparator_tb.vvp
cd ..
run yosys -l Logs/yosys.log -p 'read_verilog RTL/comparator.v; hierarchy -check -top comparator; proc; opt; check -assert; stat; show -format dot -prefix Figures/rtl_view comparator; write_json Figures/netlist.json'
run dot -Tpng Figures/rtl_view.dot -o Figures/rtl_view.png
run dot -Tpng Figures/design.dot -o Figures/design.png
