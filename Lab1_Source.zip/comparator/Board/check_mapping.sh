#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
iverilog -g2012 -Wall -s board_tb -y RTL -o Board/board_tb.vvp Board/board_tb.sv RTL/sim/DevelopmentBoard.v
vvp Board/board_tb.vvp
