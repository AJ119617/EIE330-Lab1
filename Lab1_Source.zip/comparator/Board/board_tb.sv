`timescale 1ns/1ns
module board_tb;
reg clk=0,reset=1,B2=1,B3=1,B4=1,B5=1;
wire h_sync,v_sync; wire [15:0] rgb; wire led1,led2,led3,led4,led5;
DevelopmentBoard dut(.*);
initial begin
B2=1; B3=1; #1; if({~led1,~led2,~led3} !== 3'b010) $fatal(1,"Mapping case 0 failed");
$display("MAPPING CASE 0 logical inputs=00 expected=010 actual=%b PASS",{~led1,~led2,~led3});
B2=1; B3=0; #1; if({~led1,~led2,~led3} !== 3'b100) $fatal(1,"Mapping case 1 failed");
$display("MAPPING CASE 1 logical inputs=01 expected=100 actual=%b PASS",{~led1,~led2,~led3});
B2=0; B3=1; #1; if({~led1,~led2,~led3} !== 3'b001) $fatal(1,"Mapping case 2 failed");
$display("MAPPING CASE 2 logical inputs=10 expected=001 actual=%b PASS",{~led1,~led2,~led3});
B2=0; B3=0; #1; if({~led1,~led2,~led3} !== 3'b010) $fatal(1,"Mapping case 3 failed");
$display("MAPPING CASE 3 logical inputs=11 expected=010 actual=%b PASS",{~led1,~led2,~led3});
$display("PASS all board-wrapper pin mappings"); $finish; end
endmodule
