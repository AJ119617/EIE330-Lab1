#!/bin/bash
set -uo pipefail
cd "$(dirname "$0")/.."
exec > >(tee Logs/verification.log) 2>&1
run() { echo "COMMAND: $*"; "$@"; r=$?; echo "EXIT_STATUS=$r"; [ "$r" -eq 0 ] || exit "$r"; }
cd RTL
run iverilog -Wall -t null -s full_adder full_adder.v
cd ../sim
run iverilog -Wall -o full_adder_tb.vvp -s full_adder_tb -y ../RTL full_adder_tb.v
run vvp full_adder_tb.vvp
cd ..
run yosys -l Logs/yosys.log -p 'read_verilog RTL/full_adder.v; hierarchy -check -top full_adder; proc; opt; check -assert; stat; show -format dot -prefix Figures/rtl_view full_adder; write_json Figures/netlist.json'
run dot -Tpng Figures/rtl_view.dot -o Figures/rtl_view.png
run dot -Tpng Figures/design.dot -o Figures/design.png
