`timescale 1ns / 1ns

module DevelopmentBoard(
    input wire clk,  // 50MHz
    input wire reset, B2, B3, B4, B5,
    // reset is "a"
    // B2 is "s"
    // B3 is "d"
    // B4 is "f"
    // B5 is "g"
    output wire h_sync, v_sync,
    output wire [15:0] rgb,
    output wire led1,
    output wire led2,
    output wire led3,
    output wire led4,
    output wire led5
);

full_adder full_adder_inst(
    .a_n(B2),
    .b_n(B3),
    .cin_n(B4),
    .sum_n(led1),
    .carry_n(led2)
);

endmodule
