`timescale 1ns/1ns
module board_tb;
reg clk=0,reset=1,B2=1,B3=1,B4=1,B5=1;
wire h_sync,v_sync; wire [15:0] rgb; wire led1,led2,led3,led4,led5;
DevelopmentBoard dut(.*);
initial begin
B2=1; B3=1; B4=1; #1; if({~led1,~led2} !== 2'b00) $fatal(1,"Mapping case 0 failed");
$display("MAPPING CASE 0 logical inputs=000 expected=00 actual=%b PASS",{~led1,~led2});
B2=1; B3=1; B4=0; #1; if({~led1,~led2} !== 2'b10) $fatal(1,"Mapping case 1 failed");
$display("MAPPING CASE 1 logical inputs=001 expected=10 actual=%b PASS",{~led1,~led2});
B2=1; B3=0; B4=1; #1; if({~led1,~led2} !== 2'b10) $fatal(1,"Mapping case 2 failed");
$display("MAPPING CASE 2 logical inputs=010 expected=10 actual=%b PASS",{~led1,~led2});
B2=1; B3=0; B4=0; #1; if({~led1,~led2} !== 2'b01) $fatal(1,"Mapping case 3 failed");
$display("MAPPING CASE 3 logical inputs=011 expected=01 actual=%b PASS",{~led1,~led2});
B2=0; B3=1; B4=1; #1; if({~led1,~led2} !== 2'b10) $fatal(1,"Mapping case 4 failed");
$display("MAPPING CASE 4 logical inputs=100 expected=10 actual=%b PASS",{~led1,~led2});
B2=0; B3=1; B4=0; #1; if({~led1,~led2} !== 2'b01) $fatal(1,"Mapping case 5 failed");
$display("MAPPING CASE 5 logical inputs=101 expected=01 actual=%b PASS",{~led1,~led2});
B2=0; B3=0; B4=1; #1; if({~led1,~led2} !== 2'b01) $fatal(1,"Mapping case 6 failed");
$display("MAPPING CASE 6 logical inputs=110 expected=01 actual=%b PASS",{~led1,~led2});
B2=0; B3=0; B4=0; #1; if({~led1,~led2} !== 2'b11) $fatal(1,"Mapping case 7 failed");
$display("MAPPING CASE 7 logical inputs=111 expected=11 actual=%b PASS",{~led1,~led2});
$display("PASS all board-wrapper pin mappings"); $finish; end
endmodule
