from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib
r=Path(r'D:\EIE330\lab1_tasks')
files=[p for p in r.rglob('*') if p.is_file() and 'obj_dir' not in p.parts and p.suffix not in ['.b64','.vvp'] and not p.name.startswith(('qa-','finalqa-','QA_')) and p.name not in ['Lab1_Delivery.zip','SHA256SUMS.txt']]
(r/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(r)) for p in files),encoding='utf-8')
with ZipFile(r/'Lab1_Delivery.zip','w',ZIP_DEFLATED) as z:
 for p in files+[r/'SHA256SUMS.txt']:z.write(p,p.relative_to(r))
print('Packaged',len(files),'files', (r/'Lab1_Delivery.zip').stat().st_size,'bytes')
