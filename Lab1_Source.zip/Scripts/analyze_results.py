from pathlib import Path
import json,csv,subprocess,sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from vcdvcd import VCDVCD
root=Path('D:/EIE330/lab1_tasks'); meta=json.loads((root/'metadata.json').read_text())
for name,m in meta.items():
 p=root/name;scope=name+'_tb';vcd=p/f'sim/{scope}.vcd'
 converter=root/'Scripts/vcd2csv.py'
 if not converter.exists(): converter.write_bytes(Path('D:/EIE330/lab1_led/Scripts/vcd2csv.py').read_bytes())
 result=subprocess.run([sys.executable,str(converter),'-i',str(vcd),'-o',str(p/'sim/raw_vcd.csv')],capture_output=True,text=True,check=True)
 v=VCDVCD(str(vcd));assert v.timescale['unit']=='ns' and float(v.timescale['magnitude'])==1
 n=m['n']; physical=['a_n','b_n','cin_n','sum_n','carry_n'] if n==3 else ['a_n','b_n','lt_n','eq_n','gt_n']
 def value(sig,t):
  vals=[val for time,val in v[scope+'.'+sig].tv if time<=t]
  assert vals and vals[-1] in ('0','1'),(sig,t,vals)
  return 1-int(vals[-1])
 times=sorted({time for sig in physical for time,val in v[scope+'.'+sig].tv}|{v.endtime})
 measured=[[t]+[value(sig,t) for sig in physical] for t in times]
 with (p/'sim/logical_waveform.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Time_ns']+m['signals']);w.writerows(measured)
 for r in m['rows']:
  got=[value(sig,r['time_ns']+1) for sig in physical]
  assert got==r['inputs']+r['outputs'],(r,got)
 assert v.endtime==m['end_ns']
 fig,axs=plt.subplots(len(physical),1,figsize=(9,1.15*len(physical)),sharex=True)
 for k,ax in enumerate(axs):
  ax.step(times,[r[k+1] for r in measured],where='post',lw=1.8,color='#1565c0');ax.set_ylabel(m['signals'][k]);ax.set_yticks([0,1]);ax.set_ylim(-.2,1.2);ax.grid(alpha=.25)
 axs[-1].set_xlim(0,v.endtime);axs[-1].set_xticks([r['time_ns'] for r in m['rows']]+[v.endtime]);axs[-1].set_xlabel('Time (ns)')
 fig.suptitle(name+' measured logical waveforms - decoded from actual VCD');fig.tight_layout();fig.savefig(p/'Figures/measured_waveform.png',dpi=180);fig.savefig(p/'Figures/measured_waveform.svg');plt.close(fig)
 (p/'Logs/waveform.log').write_text(result.stdout+f'PASS: {len(m["rows"])} measured VCD cases match independent design table; endtime={v.endtime} ns.\nLogical values = 1 - measured active-low port values.\n')
 # Reuse the actual official simulator release, not a replacement drawing.
 assets=Path('//wsl.localhost/Ubuntu-22.04/opt/eie330/apps/vga/data/flutter_assets/assets')
 out=p/'RTL/sim';out.mkdir(exist_ok=True)
 for f in ['simulator.cpp','run_simulation.sh']:(out/f).write_bytes((assets/'sim'/f).read_bytes())
 mapping={'B2':'a_n','B3':'b_n','B4':'cin_n','led1':'sum_n','led2':'carry_n'} if n==3 else {'B2':'a_n','B3':'b_n','led1':'lt_n','led2':'eq_n','led3':'gt_n'}
 template=(assets/'templates/development_board.v.tpl').read_text(encoding='utf-8')
 (out/'DevelopmentBoard.v').write_text(template.replace('{{module_name}}',name).replace('{{connections}}',',\n'.join('    .'+port+'('+board+')' for board,port in mapping.items())),encoding='utf-8')
 (p/'Board/applied_mapping.json').write_text(json.dumps(dict(top=name,mapping=mapping,others='unconnected',method='installed official release template; not GUI-saved config'),indent=2))
 checklist='case,A,B,'+('Cin,' if n==3 else '')+','.join(m['signals'][n:])+',board_observed,video_time\n'
 for r in m['rows']:checklist+=str(r['case'])+','+','.join(map(str,r['inputs']+r['outputs']))+',PENDING,\n'
 (p/'Board/manual_checklist.csv').write_text(checklist)
 print(name,'VCD/CSV waveforms checked; official board workspace prepared')
