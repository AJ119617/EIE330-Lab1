import csv,json
from pathlib import Path
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
root=Path(r'D:\EIE330\lab1_tasks'); meta=json.loads((root/'metadata.json').read_text())
for name,title,stat in [('full_adder','Task 1 1 Full Adder','12 cells: AND 3, NOT 5, OR 2, XOR 2'),('comparator','Task 1 2 One Bit Comparator','7 cells: AND 2, NOT 4, XOR 1')]:
 p=root/name;m=meta[name];d=Document();s=d.sections[0];s.top_margin=s.bottom_margin=Inches(.65)
 for sty in ['Normal','Title','Heading 1','Heading 2']:
  st=d.styles[sty];st.font.name='Calibri';st.font.size=Pt(10 if sty=='Normal' else 18 if sty=='Title' else 14);st.font.color.rgb=RGBColor(0,0,0);st.element.rPr.rFonts.set(qn('w:eastAsia'),'Microsoft YaHei')
  for b in st.element.xpath('.//w:pBdr'):b.getparent().remove(b)
 d.styles['Normal'].paragraph_format.space_after=Pt(6)
 def para(t):d.add_paragraph(t)
 def table(headers,rows,cap):
  para(cap);t=d.add_table(rows=1, cols=len(headers));t.style='Table Grid'
  for c,v in zip(t.rows[0].cells,headers):c.text=str(v)
  for r in rows:
   for c,v in zip(t.add_row().cells,r):c.text=str(v)
 def fig(path,cap,width=6):d.add_picture(str(path),width=Inches(width));para(cap)
 def page(head):d.add_page_break();d.add_heading(head,1)
 d.add_paragraph('EIE330 FPGA Lab 1',style='Title');d.add_paragraph(title,style='Title')
 para('报告草稿 | 2026年10月9日');para('姓名：待本人填写    学号：待本人填写\n组员及实际贡献：待本人填写')
 d.add_heading('Introduction',1)
 para('本任务研究低电平有效按钮与 LED 接口下的组合逻辑。逻辑输入 1 表示按下，逻辑输出 1 表示 LED 点亮。'+('全加器相较半加器增加进位输入，可用于多位加法的逐位进位。' if name=='full_adder' else '一位比较器判断两个输入的大小关系，三个结果互斥，可用于条件判断。'))
 para(f'真实 RTL 仿真覆盖全部 {len(m["rows"])} 种输入，全部通过。Icarus 编译、Yosys 通用综合和板级端口映射仿真通过。虚拟板人工视频已核对全部输入组合，结果通过；视频网站网址、代码仓库链接和个人信息尚待补。')
 para('AI 使用声明：AI 辅助完成需求分析、设计、RTL、testbench、自动验证、图表与报告草稿。本人须检查理解全部结果，按课程和学校政策填写实际贡献。未声称本人已经完成尚未录制的板测。')
 page('Requirements Analysis')
 para('依据正式 Lab_1_Requirements.pdf [1]，每个任务独立设计并验证所有输入组合。表1给出编码前保存的可见逻辑真值表。物理端口后缀 _n 表示低有效。按钮松开物理值为1，按下接地为0；LED物理输出0点亮 [3]。')
 table(m['signals'],[r['inputs']+r['outputs'] for r in m['rows']],'表1 设计真值表（逻辑1表示按下或点亮）')
 table(['需求','验证证据'],[['全部输入组合','sim/results.csv 与 Logs/verification.log'],['正确低有效接口','Board/applied_mapping.json 与 Logs/pin-mapping.log'],['组合逻辑无锁存器','Logs/yosys.log：无进程，无存储器'],['真实波形','sim/led-free VCD文件及 logical_waveform.csv（见目录）'],['人工虚拟板验证','Board/manual_checklist.csv；视频待补']],'表2 需求与证据对应关系')
 para('资源边界：组合逻辑无时钟、复位或存储器，不添加消抖或闪烁。Cyclone IV 是器件家族；具体器件/封装以实板型号为准。通用 Yosys 单元统计不能换算为已实现的 FPGA 逻辑单元、引脚约束或物理时序结果 [2]。')
 page('System Design')
 para('图1标明物理端口与逻辑信号。单个模块足以表达该小型组合电路；连续赋值不包含状态或不完整条件分支。先把低有效按钮译为逻辑值，再运算，最后对 LED 输出编码。')
 fig(p/'Figures/design.png','图1 模块结构与信号关系')
 para('图2为实现前保存的设计预期，输入每20 ns变化一次；此图仅定义目标，不作为实测证据。')
 fig(p/'Figures/expected_waveform.png','图2 设计预期波形',5.8)
 page('Implementation')
 para('关键逻辑如下，完整源码保存在 RTL/，报告只列核心表达式。GitHub完整代码链接：待本人授权并提供仓库。')
 para('sum = a ^ b ^ cin; carry = (a & b) | (a & cin) | (b & cin);' if name=='full_adder' else 'lt = (~a) & b; eq = ~(a ^ b); gt = a & (~b);')
 para('各输入先取反解码，最终物理 LED 输出为上述逻辑结果取反。这与直接连接的教学 LED 示例不同：本任务表达算术或比较逻辑。')
 para('Icarus 11.0：语法检查及带 -Wall 编译退出0，无警告。Yosys 0.9：hierarchy、proc、opt、check -assert、stat 和 show 均通过。图3为真实 Yosys RTL结构；统计见表3。')
 fig(p/'Figures/rtl_view.png','图3 Yosys 通用 RTL 结构',5.8)
 table(['项目','实测'],[['组合单元',stat],['进程 / 存储器','0 / 0'],['check 问题数','0'],['物理 FPGA 布局与时序','未执行']],'表3 通用综合统计')
 page('Testing')
 para('testbench明确列出每组输入及预期输出，施加输入后等待1 ns让组合赋值稳定，再读取实际端口并使用 !== 检查；失败调用 $fatal，只有全部检查通过才报告 PASS。比较器同时检查三个输出恰有一个为1。')
 para('图4来自本次实际 VCD，通过老师 vcd2csv.py [4]转换，再解码低有效物理端口并用 Python绘图。原始物理数据保留在 raw_vcd.csv，不使用 GTKWave 截图。GTKWave 已尝试打开文件；逐行自检查与数据分析是本次功能判定证据。')
 fig(p/'Figures/measured_waveform.png','图4 实际仿真波形（ns）',5.6)
 rows=list(csv.DictReader((p/'sim/results.csv').open()))
 table(['输入','期望','实际','采样ns','结果'],[[''.join(r[x] for x in m['signals'][:m['n']]),r['expected'],r['actual'],r['time_ns'],r['status']] for r in rows],'表4 全部组合期望与实际结果；输出顺序同表1')
 para('内部逻辑 a、b'+('、cin、sum、carry' if name=='full_adder' else '、lt、eq、gt')+'均保留在VCD。零延迟 RTL模型只能验证逻辑关系，不代表真实器件传播延迟或满足物理时序。')
 page('Board Test')
 para('图5来自本人提供的真实虚拟板视频，B2与B3同时绿色，LED2亮且LED1/3灭。全部四组画面已核对通过，时间索引见Board/manual_checklist.csv。未连接LED4/5不属于验收输出。' if name=='comparator' else '图5来自本人提供的真实虚拟板视频，B2/B3/B4同时绿色，LED1与LED2均亮。全部八组画面已核对通过；未连接LED3/4/5不属于验收输出。')
 fig(p/('Board/both_inputs.jpg' if name=='comparator' else 'Board/all_inputs.jpg'),'图5 比较器输入11的实际视频画面' if name=='comparator' else '图5 全加器输入111的实际视频画面',3.7)
 mapping=[['B2','a_n'],['B3','b_n']]+([['B4','cin_n'],['led1','sum_n'],['led2','carry_n']] if name=='full_adder' else [['led1','lt_n'],['led2','eq_n'],['led3','gt_n']])
 table(['板端口','RTL端口'],mapping,'表5 实际生成并编译的板端口映射；其他端口不连接')
 para('比较器全部四组人工窗口视频已核对：00只亮LED2，01只亮LED1，10只亮LED3，11只亮LED2，均与真值表一致。视频已保存本地，网址待上传。' if name=='comparator' else '全加器全部八组人工窗口视频已核对通过：000→00，001→10，010→10，011→01，100→10，101→01，110→01，111→11。视频保存本地，网址待上传；每组时间索引见Board/manual_checklist.csv。')
 para('官方源码会丢弃事件且缺少多按钮键盘操作。本地修复事件处理，并增加S=B2、D=B3、F=B4的独立按住和松开支持；失去焦点释放所有按钮。原版已备份，实验RTL未改，未自动播放真值表或生成伪造输出。录像需披露使用本地修复版。')
 page('Discussion and Conclusion')
 para('测试结果与设计真值表完全一致，连续赋值实现了无状态组合逻辑。取反只用于板接口编码/解码；算术和比较在逻辑域中完成。没有时钟，因为输出只取决于当前输入。完整输入枚举、自检查、实际 VCD 与端口映射检查共同支持逻辑正确性。')
 para(('尚需：填写姓名学号与贡献；完整代码GitHub链接；上传已录制的比较器视频并填写网址；本人核对提交。' if name=='comparator' else '尚需：姓名学号与贡献；GitHub链接；上传已录制的全加器视频并填写网址；本人核对提交。')+'本地模拟器修改已披露；如课程限制修改模拟器，须向老师确认。当前证据不足以声明正式实验的全部交付要求完成。')
 para('真实 FPGA 板没有测试。要求文件的最终硬件确认说明与本次虚拟板交付证据分开记录；是否另有实物提交事项由老师确认，不自行增加为已知必交材料。')
 d.add_heading('References',1)
 for t in ['[1] EIE330, Lab 1 Requirements, course handout, pp. 1–6, undated.','[2] Altera, Cyclone IV Device Handbook, Volume 1, device family datasheet supplied with course.','[3] Development Board Schematic Diagram, supplied course document, sheet 10.','[4] pikipity, FPGA Laboratory, vcd2csv.py, https://github.com/pikipity/FPGA-Laboratory/blob/main/Lab1_Simple_LED_Circuit/sim-wave/vcd2csv.py, accessed Oct. 9, 2026.','[5] pikipity, Simple VGA Simulator, release v1.0.0+build.18, https://github.com/pikipity/Simple-VGA-Simulator, accessed Oct. 9, 2026.','[6] Icarus Verilog 11.0 and Yosys 0.9, installed tools and generated command logs, Oct. 9, 2026.']:para(t)
 # remove accidental placeholder phrase
 for t in d.tables:
  for r in t.rows:
   for c in r.cells:
    c.text=c.text.replace('sim/led-free VCD文件及 logical_waveform.csv（见目录）','sim/ 中实际 VCD 与 logical_waveform.csv')
 d.save(root/'Reports'/f'{name}_report_draft.docx')
