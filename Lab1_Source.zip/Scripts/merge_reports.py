from pypdf import PdfReader,PdfWriter
from pathlib import Path
p=Path(r'D:\EIE330\lab1_tasks\Reports');w=PdfWriter()
for n in ['full_adder','comparator']:
 r=PdfReader(p/f'{n}_report_draft.pdf');print(n,len(r.pages))
 for i,x in enumerate(r.pages):print(i+1,(x.extract_text() or '')[:65].replace('\n',' '));w.add_page(x)
w.write(p/'Lab1_Combined_Report_DRAFT.pdf')
