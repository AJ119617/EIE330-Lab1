from pathlib import Path
r=Path(r'D:\EIE330\lab1_tasks')
for n in ['comparator','full_adder']:
 p=r/n/'RTL/sim/simulator.cpp';s=p.read_text();b=p.with_name('simulator.eventfix.cpp.bak')
 if not b.exists():b.write_bytes(p.read_bytes())
 old='''                    case SDL_KEYDOWN:
                        switch (e.key.keysym.sym) {
                            case SDLK_ESCAPE:
                            case SDLK_q:
                                std::cerr << "[Input] Quit key pressed\\n";
                                running = false;
                                break;
                        }
                        break;
'''
 new='''                    case SDL_KEYDOWN:
                    case SDL_KEYUP: {
                        const bool down = e.type == SDL_KEYDOWN;
                        if (down && (e.key.keysym.sym == SDLK_ESCAPE || e.key.keysym.sym == SDLK_q)) {
                            running = false;
                            break;
                        }
                        int index = -1;
                        switch (e.key.keysym.sym) {
                            case SDLK_s: index = 1; break; // B2
                            case SDLK_d: index = 2; break; // B3
                            case SDLK_f: index = 3; break; // B4
                            case SDLK_g: index = 4; break; // B5
                        }
                        if (index >= 0 && !e.key.repeat) {
                            keyboard_down[index] = down;
                            g_buttons[index].pressed = keyboard_down[index] || mouse_down[index];
                            keys[index].store(g_buttons[index].pressed ? 0 : 1, std::memory_order_release);
                            std::cerr << "[Keyboard] " << g_buttons[index].label << (down ? " pressed" : " released") << "\\n";
                        }
                        break;
                    }
                    case SDL_WINDOWEVENT:
                        if (e.window.event == SDL_WINDOWEVENT_FOCUS_LOST) {
                            for (int i = 0; i < 5; ++i) {
                                keyboard_down[i] = mouse_down[i] = false;
                                g_buttons[i].pressed = false;
                                keys[i].store(1, std::memory_order_release);
                            }
                            g_active_button = -1;
                        }
                        break;
'''
 assert old in s
 s=s.replace(old,new).replace('    SDL_Event e;\n    bool running = true;','    SDL_Event e;\n    bool keyboard_down[5] = {};\n    bool mouse_down[5] = {};\n    bool running = true;')
 s=s.replace('g_buttons[i].pressed = true;\n                                    g_active_button', 'mouse_down[i] = true;\n                                    g_buttons[i].pressed = true;\n                                    g_active_button')
 s=s.replace('g_buttons[i].pressed = false;\n                            keys[i].store(1,', 'mouse_down[i] = false;\n                            g_buttons[i].pressed = keyboard_down[i];\n                            keys[i].store(keyboard_down[i] ? 0 : 1,')
 s=s.replace('g_buttons[i].pressed = false;\n                                keys[i].store(1,', 'mouse_down[i] = false;\n                                g_buttons[i].pressed = keyboard_down[i];\n                                keys[i].store(keyboard_down[i] ? 0 : 1,')
 p.write_text(s)
with (r/'SIMULATOR_FIX.md').open('a',encoding='utf-8') as f:f.write('\nKeyboard interaction added: hold S=B2, D=B3, F=B4, G=B5. Each key independently drives the original active-low button pin; key release releases it. Focus loss releases all buttons. Keyboard and mouse state are combined. No truth-table playback or automatic DUT output generation; no RTL changes. This is a locally modified simulator, to be disclosed in the report.\n')
