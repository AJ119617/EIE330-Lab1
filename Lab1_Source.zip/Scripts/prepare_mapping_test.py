from pathlib import Path
import json
root=Path('D:/EIE330/lab1_tasks');meta=json.loads((root/'metadata.json').read_text())
for name,m in meta.items():
 p=root/name;n=m['n'];tb='''`timescale 1ns/1ns
module board_tb;
reg clk=0,reset=1,B2=1,B3=1,B4=1,B5=1;
wire h_sync,v_sync; wire [15:0] rgb; wire led1,led2,led3,led4,led5;
DevelopmentBoard dut(.*);
initial begin
'''
 for r in m['rows']:
  inp=r['inputs'];out=r['outputs'];assign='B2='+str(1-inp[0])+'; B3='+str(1-inp[1])+'; '
  if n==3:assign+='B4='+str(1-inp[2])+'; '
  lhs='{~led1,~led2}' if n==3 else '{~led1,~led2,~led3}'
  bits=''.join(map(str,out));tb+=assign+f'#1; if({lhs} !== {len(out)}\'b{bits}) $fatal(1,"Mapping case {r["case"]} failed");\n$display("MAPPING CASE {r["case"]} logical inputs={"".join(map(str,inp))} expected={bits} actual=%b PASS",{lhs});\n'
 tb+='$display("PASS all board-wrapper pin mappings"); $finish; end\nendmodule\n'
 (p/'Board/board_tb.sv').write_text(tb)
 (p/'Board/check_mapping.sh').write_text(f'''#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
iverilog -g2012 -Wall -s board_tb -y RTL -o Board/board_tb.vvp Board/board_tb.sv RTL/sim/DevelopmentBoard.v
vvp Board/board_tb.vvp
''',newline='\n')
