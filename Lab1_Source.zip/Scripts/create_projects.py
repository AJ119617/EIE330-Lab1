from pathlib import Path
import csv,json,shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('D:/EIE330/lab1_tasks')
if (root/'full_adder/RTL/full_adder.v').exists():
 raise SystemExit('Existing formal project found; inspect before modifying')
meta={}
for name,n in [('full_adder',3),('comparator',2)]:
 p=root/name
 for folder in ['RTL','sim','Doc','Figures','Logs','Board']:(p/folder).mkdir(parents=True,exist_ok=True)
 rows=[]
 for i in range(2**n):
  ins=[(i>>b)&1 for b in range(n-1,-1,-1)]
  if n==3:
   total=sum(ins); outs=[total%2,total//2]
  else:
   a,b=ins;outs=[int(a<b),int(a==b),int(a>b)]
  rows.append(dict(case=i,time_ns=i*20,inputs=ins,outputs=outs))
 signals=['A','B','Cin','S','Cout'] if n==3 else ['A','B','LT','EQ','GT']
 meta[name]=dict(name=name,n=n,rows=rows,signals=signals,end_ns=20*2**n)
 # Expected evidence authored before RTL, independent from measured VCD.
 with (p/'Doc/expected_truth_table.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['case','time_ns']+signals)
  for r in rows:w.writerow([r['case'],r['time_ns']]+r['inputs']+r['outputs'])
 fig,axs=plt.subplots(len(signals),1,figsize=(9,1.1*len(signals)),sharex=True)
 for k,(ax,sig) in enumerate(zip(axs,signals)):
  x=[r['time_ns'] for r in rows]+[20*2**n];y=[(r['inputs']+r['outputs'])[k] for r in rows];y.append(y[-1])
  ax.step(x,y,where='post');ax.set_ylabel(sig);ax.set_yticks([0,1]);ax.set_ylim(-.2,1.2);ax.grid(alpha=.2)
 axs[-1].set_xlabel('Time (ns)');fig.suptitle(name+' expected logical waveforms - design specification');fig.tight_layout();fig.savefig(p/'Figures/expected_waveform.png',dpi=180);plt.close(fig)
 dot='digraph design { rankdir=LR; node [shape=box]; inputs [label="'+('A_n B_n Cin_n' if n==3 else 'A_n B_n')+'"]; decode [label="Active-low input decode"]; core [label="'+('Full adder S=A^B^Cin\nCout=AB+ACin+BCin' if n==3 else 'Comparator LT=~A&B\nEQ=~(A^B) GT=A&~B')+'"]; encode [label="Active-low LED encode"]; outputs [label="'+('sum_n carry_n' if n==3 else 'lt_n eq_n gt_n')+'"]; inputs -> decode [label="physical inputs"]; decode -> core [label="logical inputs"]; core -> encode [label="logical results"]; encode -> outputs [label="physical outputs"]; }'
 (p/'Figures/design.dot').write_text(dot,encoding='utf-8')
 (p/'Doc/design_spec.json').write_text(json.dumps(meta[name],indent=2))
(root/'metadata.json').write_text(json.dumps(meta,indent=2))
fa='''`timescale 1ns/1ns
module full_adder(input wire a_n, b_n, cin_n,
                  output wire sum_n, carry_n);
    wire a = ~a_n;
    wire b = ~b_n;
    wire cin = ~cin_n;
    wire sum = a ^ b ^ cin;
    wire carry = (a & b) | (a & cin) | (b & cin);
    assign sum_n = ~sum;
    assign carry_n = ~carry;
endmodule
'''
co='''`timescale 1ns/1ns
module comparator(input wire a_n, b_n,
                  output wire lt_n, eq_n, gt_n);
    wire a = ~a_n;
    wire b = ~b_n;
    wire lt = (~a) & b;
    wire eq = ~(a ^ b);
    wire gt = a & (~b);
    assign lt_n = ~lt;
    assign eq_n = ~eq;
    assign gt_n = ~gt;
endmodule
'''
(root/'full_adder/RTL/full_adder.v').write_text(fa)
(root/'comparator/RTL/comparator.v').write_text(co)
for name,m in meta.items():
 n=m['n'];p=root/name
 reg='a_n, b_n, cin_n' if n==3 else 'a_n, b_n'
 wires='sum_n, carry_n' if n==3 else 'lt_n, eq_n, gt_n'
 con='.a_n(a_n), .b_n(b_n), '+('.cin_n(cin_n), .sum_n(sum_n), .carry_n(carry_n)' if n==3 else '.lt_n(lt_n), .eq_n(eq_n), .gt_n(gt_n)')
 tb=f'`timescale 1ns/1ns\nmodule {name}_tb;\n reg {reg};\n wire {wires};\n integer checks=0;\n integer fd;\n {name} dut ({con});\n initial begin\n  $dumpfile("{name}_tb.vcd");\n  $dumpvars(0,{name}_tb);\n  fd=$fopen("results.csv","w");\n  if(fd==0) $fatal(1,"Cannot open results.csv");\n'
 tb+='  $fdisplay(fd,"case,time_ns,'+','.join(m['signals'])+',expected,actual,status");\n'
 for r in m['rows']:
  ins=''.join(map(str,r['inputs']));exp=''.join(map(str,r['outputs']))
  lhs='{a_n,b_n,cin_n}' if n==3 else '{a_n,b_n}'
  actual='{~sum_n,~carry_n}' if n==3 else '{~lt_n,~eq_n,~gt_n}'
  logical='{~a_n,~b_n,~cin_n}' if n==3 else '{~a_n,~b_n}'
  delay='' if r['case']==0 else '  #19;\n'
  tb+=delay+f'  // Case {r["case"]}: logical inputs {ins}, expected logical outputs {exp}\n  {lhs}=~{n}\'b{ins}; #1;\n  if ({actual} !== {len(exp)}\'b{exp}) $fatal(1,"Case {r["case"]} failed");\n'
  if n==2:tb+='  if (({~lt_n,~eq_n,~gt_n} !== 3\'b100) && ({~lt_n,~eq_n,~gt_n} !== 3\'b010) && ({~lt_n,~eq_n,~gt_n} !== 3\'b001)) $fatal(1,"Not one hot");\n'
  allvars=('~a_n,~b_n,~cin_n,~sum_n,~carry_n' if n==3 else '~a_n,~b_n,~lt_n,~eq_n,~gt_n')
  tb+=f'  checks=checks+1;\n  $fdisplay(fd,"{r["case"]},%0t,'+','.join(['%b']*len(m['signals']))+f',{exp},%b,PASS",$time,{allvars},{actual});\n  $display("CASE {r["case"]} inputs={ins} expected={exp} actual=%b PASS",{actual});\n'
 tb+=f'  #19;\n  if(checks!={2**n}) $fatal(1,"Missing cases");\n  $fclose(fd);\n  $display("PASS {name}: %0d cases",checks);\n  $finish;\n end\nendmodule\n'
 (p/f'sim/{name}_tb.v').write_text(tb)
 # Verification scripts record every command and return code.
 sh=f'''#!/bin/bash
set -uo pipefail
cd "$(dirname "$0")/.."
exec > >(tee Logs/verification.log) 2>&1
run() {{ echo "COMMAND: $*"; "$@"; r=$?; echo "EXIT_STATUS=$r"; [ "$r" -eq 0 ] || exit "$r"; }}
cd RTL
run iverilog -Wall -t null -s {name} {name}.v
cd ../sim
run iverilog -Wall -o {name}_tb.vvp -s {name}_tb -y ../RTL {name}_tb.v
run vvp {name}_tb.vvp
cd ..
run yosys -l Logs/yosys.log -p 'read_verilog RTL/{name}.v; hierarchy -check -top {name}; proc; opt; check -assert; stat; show -format dot -prefix Figures/rtl_view {name}; write_json Figures/netlist.json'
run dot -Tpng Figures/rtl_view.dot -o Figures/rtl_view.png
run dot -Tpng Figures/design.dot -o Figures/design.png
'''
 (p/'Scripts').mkdir(exist_ok=True);(p/'Scripts/verify.sh').write_text(sh,newline='\n')
print('Created expected designs first, then RTL and explicit truth-table self-checks')
