from pathlib import Path
for name,n in [('full_adder',3),('comparator',2)]:
 p=Path('D:/EIE330/lab1_tasks')/name/'Figures/design.dot'
 s=p.read_text().replace('label="logical inputs"','label="'+('A, B, Cin' if n==3 else 'A, B')+'"').replace('label="logical results"','label="'+('S, Cout' if n==3 else 'LT, EQ, GT')+'"');p.write_text(s)
