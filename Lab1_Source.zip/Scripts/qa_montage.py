from PIL import Image,ImageOps,ImageDraw
from pathlib import Path
p=Path(r'D:\EIE330\lab1_tasks\Reports');files=sorted(p.glob('finalqa-*.png'));out=Image.new('RGB',(1200, ((len(files)+3)//4)*440),'#aaa')
for i,f in enumerate(files):
 im=Image.open(f);im.thumbnail((290,410));out.paste(im,((i%4)*300,(i//4)*440));ImageDraw.Draw(out).text(((i%4)*300,(i//4)*440+412),f.name,fill='black')
out.save(p/'QA_contact_sheet.png')
