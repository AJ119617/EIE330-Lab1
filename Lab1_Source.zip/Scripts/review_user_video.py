import av,shutil
from pathlib import Path
from PIL import Image,ImageDraw
src=Path(r'C:\Users\xiaomi\Documents\xwechat_files\wxid_g32kchjpem6222_571b\msg\video\2026-10\95020007d9dca453a17718edd8329a0e.mp4');out=Path(r'D:\EIE330\lab1_tasks\comparator\Board\video_review');out.mkdir(exist_ok=True)
shutil.copy2(src,out.parent/'comparator_user_video.mp4')
c=av.open(str(src));v=c.streams.video[0];print('duration',float(c.duration/av.time_base),'size',v.width,v.height)
frames=[];nexttime=0
for f in c.decode(video=0):
 t=float(f.time or 0)
 if t>=nexttime:
  im=f.to_image();im.save(out/f'{t:.1f}s.jpg');im.thumbnail((380,300));frames.append((t,im.copy()));nexttime+=1
sheet=Image.new('RGB',(4*400,((len(frames)+3)//4)*330),'white');draw=ImageDraw.Draw(sheet)
for i,(t,im) in enumerate(frames):
 x=(i%4)*400;y=(i//4)*330;sheet.paste(im,(x,y));draw.text((x,y+300),f'{t:.1f} seconds',fill='black')
sheet.save(out/'contact_sheet.jpg');print(len(frames),'sampled frames')
