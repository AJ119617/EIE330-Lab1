from pathlib import Path
import json
root=Path('D:/EIE330/lab1_tasks')
for name,m in json.loads((root/'metadata.json').read_text()).items():
 sigs=['a_n','b_n','cin_n','sum_n','carry_n'] if m['n']==3 else ['a_n','b_n','lt_n','eq_n','gt_n']
 scope=name+'_tb'; base='/mnt/d/EIE330/lab1_tasks/'+name+'/sim/'+scope
 content=f'[dumpfile] "{base}.vcd"\n[timestart] 0\n[size] 1000 600\n[pos] 100 100\n*-13.5\n@28\n'+'\n'.join(scope+'.'+s for s in sigs)+'\n'
 (root/name/f'sim/{scope}.gtkw').write_text(content)
